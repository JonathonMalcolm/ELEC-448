function Rot2EqAngle( RotMatrix )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

Nu = acosd((RotMatrix(1,1) + RotMatrix(2,2) + RotMatrix(3,3) - 1)/2);
if (Nu == 0)
    fprintf('Nu = 0 in this special case so the unit vector R is arbitrary.\n');
elseif (Nu == 180)
    fprintf('Nu = 180 in this special case so the unit vector R is arbitrary.\n');
else
    r = [RotMatrix(3,2)-RotMatrix(2,3);RotMatrix(1,3)-RotMatrix(3,1);RotMatrix(2,1)-RotMatrix(1,2)];
    R = 1/(2*sind(Nu)).*r;
    fprintf('Nu = %0.2f \nR = (%0.2f, %0.2f, %0.2f)\n',Nu,R(1),R(2),R(3));
end

end

